__version__ = '2.6.0'
git_version = 'd8831425203385077a03c1d92cfbbe3bf2106008'
